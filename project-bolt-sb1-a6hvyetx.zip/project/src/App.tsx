import React from 'react';
import { Shield, Cloud, Terminal, Server, Database, Lock, GitBranch, Monitor, Award, ExternalLink, Github, Linkedin, Mail, Pocket as Docker, Cpu, LineChart, Bell, AlertCircle, Activity, GraduationCap, BookOpen, Scroll, Network } from 'lucide-react';

function App() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100">
      {/* Hero Section */}
      <header className="relative h-screen flex items-center justify-center bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&q=80')",
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}></div>
        <div className="container mx-auto px-6 z-10 text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
            Subhendu Kumar Parhi
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-300">
            DevOps Engineer | Cloud Security Enthusiast | Linux Administrator
          </p>
          <div className="flex justify-center gap-4">
            <a href="#contact" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg transition-all">
              Contact Me
            </a>
            <a href="#projects" className="border border-blue-600 hover:bg-blue-600/10 px-6 py-3 rounded-lg transition-all">
              View Skills
            </a>
          </div>
        </div>
      </header>

      {/* Education Section */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Education</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-all">
              <GraduationCap className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Bachelor of Computer Applications</h3>
              <p className="text-gray-400">Academy Of Business Administration (ABA)</p>
              <p className="text-gray-500">2022 - 2025</p>
            </div>
            <div className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-all">
              <BookOpen className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Diploma in Pharmacy</h3>
              <p className="text-gray-400">Kalinga Institute Of Pharmaceutical Science</p>
              <p className="text-gray-500">2018 - 2021</p>
            </div>
            <div className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-all">
              <Scroll className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Higher Secondary (+2 Science)</h3>
              <p className="text-gray-400">Baba Panchalingeswar Jr College</p>
              <p className="text-gray-500">2016 - 2018</p>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Technical Expertise</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-6 bg-gray-800 rounded-xl hover:transform hover:scale-105 transition-all">
              <Cloud className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Cloud & DevOps</h3>
              <ul className="space-y-2 text-gray-400">
                <li>AWS (EC2, VPC, Route 53)</li>
                <li>CloudWatch Monitoring</li>
                <li>Docker Containerization</li>
                <li>Jenkins CI/CD</li>
                <li>Terraform Infrastructure</li>
              </ul>
            </div>
            <div className="p-6 bg-gray-800 rounded-xl hover:transform hover:scale-105 transition-all">
              <Terminal className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">System Administration</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Linux (Ubuntu, Kali)</li>
                <li>Git & GitHub</li>
                <li>Bash Scripting</li>
                <li>System Monitoring</li>
                <li>Log Analysis</li>
              </ul>
            </div>
            <div className="p-6 bg-gray-800 rounded-xl hover:transform hover:scale-105 transition-all">
              <Shield className="w-12 h-12 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Security & Networking</h3>
              <ul className="space-y-2 text-gray-400">
                <li>Nmap & Wireshark</li>
                <li>TCP/IP & OSI Model</li>
                <li>Cisco Packet Tracer</li>
                <li>Network Security</li>
                <li>Security Monitoring</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Featured Projects</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-all">
              <Network className="w-10 h-10 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Network Security Assessment</h3>
              <p className="text-gray-400 mb-4">
                Conducted comprehensive vulnerability assessments using Nmap and performed detailed packet analysis with Wireshark for network security evaluation.
              </p>
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">Nmap</span>
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">Wireshark</span>
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">Security</span>
              </div>
              <div className="flex gap-4">
                <a href="https://github.com/subhendu345" className="text-blue-500 hover:text-blue-400 flex items-center gap-2">
                  <Github className="w-5 h-5" /> Code
                </a>
              </div>
            </div>
            <div className="bg-gray-900 rounded-xl p-6 hover:transform hover:scale-105 transition-all">
              <Activity className="w-10 h-10 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-3">CI/CD Pipeline Implementation</h3>
              <p className="text-gray-400 mb-4">
                Created automated CI/CD pipelines using Jenkins, integrating with Docker for containerization and AWS for deployment.
              </p>
              <div className="flex flex-wrap gap-2 mb-4">
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">Jenkins</span>
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">Docker</span>
                <span className="px-3 py-1 bg-blue-500/10 text-blue-400 rounded-full text-sm">AWS</span>
              </div>
              <div className="flex gap-4">
                <a href="https://github.com/subhendu345" className="text-blue-500 hover:text-blue-400 flex items-center gap-2">
                  <Github className="w-5 h-5" /> Code
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Certifications Section */}
      <section className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Certifications & Training</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-800 rounded-xl p-6">
              <Cloud className="w-10 h-10 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-4">AWS Basics</h3>
              <ul className="space-y-3 text-gray-400">
                <li>EC2 Instance Management</li>
                <li>VPC Configuration</li>
                <li>IAM Security</li>
                <li>CloudWatch Monitoring</li>
              </ul>
            </div>
            <div className="bg-gray-800 rounded-xl p-6">
              <Network className="w-10 h-10 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-4">Networking Fundamentals</h3>
              <ul className="space-y-3 text-gray-400">
                <li>Cisco Networking Academy</li>
                <li>Greek for Geeks Training</li>
                <li>Network Protocols</li>
                <li>Security Fundamentals</li>
              </ul>
            </div>
            <div className="bg-gray-800 rounded-xl p-6">
              <Shield className="w-10 h-10 text-blue-500 mb-4" />
              <h3 className="text-xl font-semibold mb-4">Cybersecurity</h3>
              <ul className="space-y-3 text-gray-400">
                <li>Cybrary Training</li>
                <li>Hack The Box Labs</li>
                <li>Penetration Testing</li>
                <li>Security Best Practices</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Learning Resources */}
      <section className="py-20 bg-gray-800">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Continuous Learning</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-gray-900 rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Learning Platforms</h3>
              <ul className="space-y-3 text-gray-400">
                <li className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-500" />
                  Cybrary Security Training
                </li>
                <li className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-500" />
                  Hack The Box Labs
                </li>
                <li className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-500" />
                  Cisco Networking Academy
                </li>
                <li className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-blue-500" />
                  PortSwigger Web Security
                </li>
              </ul>
            </div>
            <div className="bg-gray-900 rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Additional Resources</h3>
              <ul className="space-y-3 text-gray-400">
                <li className="flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-blue-500" />
                  NetworkChhok
                </li>
                <li className="flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-blue-500" />
                  Edureka
                </li>
                <li className="flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-blue-500" />
                  FreeCodeCamp
                </li>
                <li className="flex items-center gap-2">
                  <Monitor className="w-5 h-5 text-blue-500" />
                  IBM Learning
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-gray-900">
        <div className="container mx-auto px-6">
          <h2 className="text-3xl font-bold mb-12 text-center">Get In Touch</h2>
          <div className="flex justify-center space-x-8">
            <a href="https://github.com/subhendu345" className="flex items-center gap-2 text-gray-400 hover:text-blue-500 transition-colors">
              <Github className="w-6 h-6" />
              <span>GitHub</span>
            </a>
            <a href="https://linkedin.com/in/subhendu-parhi" className="flex items-center gap-2 text-gray-400 hover:text-blue-500 transition-colors">
              <Linkedin className="w-6 h-6" />
              <span>LinkedIn</span>
            </a>
            <a href="mailto:parhisubhendu20@gmail.com" className="flex items-center gap-2 text-gray-400 hover:text-blue-500 transition-colors">
              <Mail className="w-6 h-6" />
              <span>Email</span>
            </a>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-6 bg-gray-900 text-center text-gray-400">
        <p>© 2024 Subhendu Kumar Parhi. All rights reserved.</p>
      </footer>
    </div>
  );
}

export default App;