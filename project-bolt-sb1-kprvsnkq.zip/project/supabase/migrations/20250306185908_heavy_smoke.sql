/*
  # Create users and settings tables

  1. New Tables
    - `users`
      - `id` (uuid, primary key, matches auth.users.id)
      - `email` (text, unique)
      - `created_at` (timestamp)
    - `user_settings`
      - `user_id` (uuid, foreign key to users.id)
      - `theme` (text)
      - `two_factor_enabled` (boolean)
      - `max_voice_recording_length` (integer)
      - `max_image_uploads` (integer)
      - `preferred_domain` (text)

  2. Security
    - Enable RLS on both tables
    - Add policies for users to read/update their own data
*/

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  email text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS user_settings (
  user_id uuid PRIMARY KEY REFERENCES users(id),
  theme text DEFAULT 'light',
  two_factor_enabled boolean DEFAULT false,
  max_voice_recording_length integer DEFAULT 3600,
  max_image_uploads integer DEFAULT 10,
  preferred_domain text DEFAULT 'general',
  CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read own data"
  ON users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own data"
  ON users
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can read own settings"
  ON user_settings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own settings"
  ON user_settings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);