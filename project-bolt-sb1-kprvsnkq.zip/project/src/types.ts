export type InputType = 'text' | 'image' | 'voice' | 'video';
export type Domain = 'general' | 'cooking' | 'technology' | 'education' | 'development' | 'cybersecurity';
export type Theme = 'light' | 'dark';

export interface User {
  id: string;
  email: string;
  settings: UserSettings;
  created_at: string;
}

export interface UserSettings {
  theme: Theme;
  twoFactorEnabled: boolean;
  maxVoiceRecordingLength: number;
  maxImageUploads: number;
  preferredDomain: Domain;
}

export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  source?: 'core' | 'enhanced' | 'research' | 'creative';
  confidence?: number;
  timestamp: number;
  inputType?: InputType;
  domain?: Domain;
  mediaUrl?: string;
  references?: Reference[];
  verified?: boolean;
  userId?: string;
}

export interface Reference {
  title: string;
  url: string;
  source: string;
  reliability: number;
  verificationStatus: 'pending' | 'verified' | 'disputed';
}

export interface Conversation {
  messages: Message[];
  loading: boolean;
  selectedDomain: Domain;
}

export interface AIModel {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  accuracy: number;
  trainingData: string[];
}

export interface LearningMetric {
  category: string;
  accuracy: number;
  interactions: number;
  lastUpdated: number;
  verificationScore: number;
}

export interface SearchResult {
  content: string;
  source: string;
  confidence: number;
  references: Reference[];
  verificationStatus: 'verified' | 'pending' | 'disputed';
}

export interface AuthState {
  user: User | null;
  session: any | null;
  loading: boolean;
}