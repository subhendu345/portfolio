import React, { useState } from 'react';
import { Settings as SettingsIcon, Moon, Sun, Shield, Clock, Image as ImageIcon } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import type { Theme, Domain } from '../types';

export function Settings() {
  const { auth, updateUser } = useAuth();
  const [isSaving, setIsSaving] = useState(false);

  const handleThemeChange = async (theme: Theme) => {
    if (!auth.user) return;
    
    setIsSaving(true);
    try {
      await updateUser({
        settings: {
          ...auth.user.settings,
          theme,
        },
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleTwoFactorToggle = async () => {
    if (!auth.user) return;
    
    setIsSaving(true);
    try {
      await updateUser({
        settings: {
          ...auth.user.settings,
          twoFactorEnabled: !auth.user.settings.twoFactorEnabled,
        },
      });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 to-blue-900 text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center gap-3 mb-8">
          <SettingsIcon className="h-8 w-8 text-blue-400" />
          <h1 className="text-3xl font-bold">Settings</h1>
        </div>

        <div className="space-y-8">
          {/* Theme Settings */}
          <section className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Sun className="h-5 w-5 text-blue-400" />
              Appearance
            </h2>
            <div className="flex gap-4">
              <button
                onClick={() => handleThemeChange('light')}
                className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                  auth.user?.settings.theme === 'light'
                    ? 'bg-blue-500 text-white'
                    : 'bg-blue-900/50 hover:bg-blue-800/50'
                }`}
              >
                <Sun className="h-4 w-4" />
                Light
              </button>
              <button
                onClick={() => handleThemeChange('dark')}
                className={`px-4 py-2 rounded-lg flex items-center gap-2 ${
                  auth.user?.settings.theme === 'dark'
                    ? 'bg-blue-500 text-white'
                    : 'bg-blue-900/50 hover:bg-blue-800/50'
                }`}
              >
                <Moon className="h-4 w-4" />
                Dark
              </button>
            </div>
          </section>

          {/* Security Settings */}
          <section className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <Shield className="h-5 w-5 text-blue-400" />
              Security
            </h2>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-medium">Two-Factor Authentication</h3>
                  <p className="text-sm text-blue-300">Add an extra layer of security to your account</p>
                </div>
                <button
                  onClick={handleTwoFactorToggle}
                  className={`relative inline-flex h-6 w-11 items-center rounded-full ${
                    auth.user?.settings.twoFactorEnabled ? 'bg-blue-500' : 'bg-blue-900/50'
                  }`}
                >
                  <span
                    className={`inline-block h-4 w-4 transform rounded-full bg-white transition ${
                      auth.user?.settings.twoFactorEnabled ? 'translate-x-6' : 'translate-x-1'
                    }`}
                  />
                </button>
              </div>
            </div>
          </section>

          {/* Upload Settings */}
          <section className="bg-white/10 backdrop-blur-lg rounded-xl p-6">
            <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
              <ImageIcon className="h-5 w-5 text-blue-400" />
              Upload Limits
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Maximum Voice Recording Length</label>
                <select
                  value={auth.user?.settings.maxVoiceRecordingLength}
                  onChange={(e) => updateUser({
                    settings: {
                      ...auth.user?.settings,
                      maxVoiceRecordingLength: parseInt(e.target.value),
                    },
                  })}
                  className="w-full bg-blue-900/50 border border-blue-400/30 rounded-lg px-3 py-2"
                >
                  <option value={300}>5 minutes</option>
                  <option value={1800}>30 minutes</option>
                  <option value={3600}>1 hour</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Maximum Image Uploads</label>
                <select
                  value={auth.user?.settings.maxImageUploads}
                  onChange={(e) => updateUser({
                    settings: {
                      ...auth.user?.settings,
                      maxImageUploads: parseInt(e.target.value),
                    },
                  })}
                  className="w-full bg-blue-900/50 border border-blue-400/30 rounded-lg px-3 py-2"
                >
                  <option value={5}>5 images</option>
                  <option value={10}>10 images</option>
                  <option value={20}>20 images</option>
                </select>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}