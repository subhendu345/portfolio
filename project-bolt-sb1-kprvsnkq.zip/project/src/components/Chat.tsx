const Chat = () => {
    return <div>Chat Component</div>;
};

export default Chat; // ✅ Ensure this line is present
