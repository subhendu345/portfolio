import React, { useState, useRef } from 'react';
import { Camera, Mic, Upload, X, Image } from 'lucide-react';
import { useReactMediaRecorder } from 'react-media-recorder';
import type { InputType } from '../types';

interface InputControlsProps {
  onMediaCapture: (type: InputType, data: string) => void;
  onClose: () => void;
}

export function InputControls({ onMediaCapture, onClose }: InputControlsProps) {
  const [activeInput, setActiveInput] = useState<InputType | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const { status: audioStatus, startRecording: startAudio, stopRecording: stopAudio, mediaBlobUrl: audioUrl } = 
    useReactMediaRecorder({ audio: true });
    
  const { status: videoStatus, startRecording: startVideo, stopRecording: stopVideo, mediaBlobUrl: videoUrl } = 
    useReactMediaRecorder({ video: true });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onMediaCapture('image', reader.result as string);
        setActiveInput(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleStopRecording = (type: InputType, url: string | null) => {
    if (url) {
      onMediaCapture(type, url);
      setActiveInput(null);
    }
  };

  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-lg">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-700">Media Input</h3>
        <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
          <X size={20} />
        </button>
      </div>

      <div className="flex gap-4">
        <button
          onClick={() => {
            fileInputRef.current?.click();
            setActiveInput('image');
          }}
          className="flex items-center gap-2 px-4 py-2 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100"
        >
          <Image size={20} />
          <span>Image</span>
        </button>

        <button
          onClick={() => {
            setActiveInput('voice');
            if (audioStatus === 'recording') {
              stopAudio();
            } else {
              startAudio();
            }
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
            audioStatus === 'recording'
              ? 'bg-red-50 text-red-600'
              : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
          }`}
        >
          <Mic size={20} />
          <span>{audioStatus === 'recording' ? 'Stop' : 'Voice'}</span>
        </button>

        <button
          onClick={() => {
            setActiveInput('video');
            if (videoStatus === 'recording') {
              stopVideo();
            } else {
              startVideo();
            }
          }}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg ${
            videoStatus === 'recording'
              ? 'bg-red-50 text-red-600'
              : 'bg-blue-50 text-blue-600 hover:bg-blue-100'
          }`}
        >
          <Camera size={20} />
          <span>{videoStatus === 'recording' ? 'Stop' : 'Video'}</span>
        </button>
      </div>

      <input
        type="file"
        ref={fileInputRef}
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
      />

      {audioUrl && audioStatus === 'stopped' && (
        <div className="mt-2">
          <audio src={audioUrl} controls className="w-full" />
          <button
            onClick={() => handleStopRecording('voice', audioUrl)}
            className="mt-2 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Send Voice Recording
          </button>
        </div>
      )}

      {videoUrl && videoStatus === 'stopped' && (
        <div className="mt-2">
          <video src={videoUrl} controls className="w-full rounded-lg" />
          <button
            onClick={() => handleStopRecording('video', videoUrl)}
            className="mt-2 w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Send Video Recording
          </button>
        </div>
      )}
    </div>
  );
}