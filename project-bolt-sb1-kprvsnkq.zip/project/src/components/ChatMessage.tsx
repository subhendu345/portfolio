import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Brain, User, ExternalLink } from 'lucide-react';
import type { Message } from '../types';

interface ChatMessageProps {
  message: Message;
}

const sourceColors = {
  core: 'text-blue-600',
  enhanced: 'text-purple-600',
  research: 'text-green-600',
  creative: 'text-orange-600'
};

export function ChatMessage({ message }: ChatMessageProps) {
  const isUser = message.role === 'user';
  
  return (
    <div className={`flex gap-4 p-6 ${isUser ? 'bg-white' : 'bg-blue-50'}`}>
      <div className={`w-10 h-10 flex items-center justify-center rounded-full ${
        isUser ? 'bg-blue-100' : 'bg-blue-200'
      }`}>
        {isUser ? <User size={24} className="text-blue-600" /> : <Brain size={24} className="text-blue-600" />}
      </div>
      <div className="flex-1">
        {message.source && !isUser && (
          <div className={`text-sm mb-1 flex items-center gap-2 ${sourceColors[message.source]}`}>
            <span className="font-medium">WiseAI {message.source}</span>
            {message.confidence && (
              <span className="text-gray-500">
                Confidence: {(message.confidence * 100).toFixed(1)}%
              </span>
            )}
          </div>
        )}
        
        {message.mediaUrl && (
          <div className="mb-4">
            {message.inputType === 'image' && (
              <img src={message.mediaUrl} alt="User input" className="max-w-md rounded-lg" />
            )}
            {message.inputType === 'video' && (
              <video src={message.mediaUrl} controls className="max-w-md rounded-lg" />
            )}
            {message.inputType === 'voice' && (
              <audio src={message.mediaUrl} controls className="w-full max-w-md" />
            )}
          </div>
        )}

        <ReactMarkdown className="prose max-w-none">
          {message.content}
        </ReactMarkdown>

        {message.references && message.references.length > 0 && (
          <div className="mt-4 border-t border-blue-100 pt-4">
            <h4 className="text-sm font-medium text-gray-700 mb-2">References:</h4>
            <div className="space-y-2">
              {message.references.map((ref, index) => (
                <a
                  key={index}
                  href={ref.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-800"
                >
                  <ExternalLink size={14} />
                  <span>{ref.title}</span>
                  <span className="text-gray-500">({ref.source})</span>
                </a>
              ))}
            </div>
          </div>
        )}

        <div className="text-xs text-gray-400 mt-2">
          {new Date(message.timestamp).toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}