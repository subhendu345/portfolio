import React, { useState } from 'react';
import TextareaAutosize from 'react-textarea-autosize';
import { Send, Loader2 } from 'lucide-react';
import { InputControls } from './InputControls';
import type { InputType } from '../types';

interface ChatInputProps {
  onSend: (message: string, inputType?: InputType, mediaUrl?: string) => void;
  disabled?: boolean;
}

export function ChatInput({ onSend, disabled }: ChatInputProps) {
  const [input, setInput] = useState('');
  const [mediaInput, setMediaInput] = useState<{ type: InputType; url: string } | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if ((input.trim() || mediaInput) && !disabled) {
      onSend(input.trim(), mediaInput?.type, mediaInput?.url);
      setInput('');
      setMediaInput(null);
    }
  };

  const handleMediaCapture = (type: InputType, url: string) => {
    setMediaInput({ type, url });
  };

  return (
    <div className="border-t bg-white">
      <form onSubmit={handleSubmit} className="max-w-4xl mx-auto p-4">
        <div className="flex flex-col gap-4">
          <InputControls onMediaCapture={handleMediaCapture} />
          
          {mediaInput && (
            <div className="bg-blue-50 p-2 rounded-lg">
              {mediaInput.type === 'image' && (
                <img src={mediaInput.url} alt="Preview" className="max-h-32 rounded" />
              )}
              {mediaInput.type === 'video' && (
                <video src={mediaInput.url} className="max-h-32 rounded" />
              )}
              {mediaInput.type === 'voice' && (
                <audio src={mediaInput.url} controls className="w-full" />
              )}
            </div>
          )}

          <div className="flex gap-4">
            <TextareaAutosize
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask WiseAI anything..."
              className="flex-1 resize-none rounded-lg border border-blue-200 p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white"
              maxRows={5}
              disabled={disabled}
            />
            <button
              type="submit"
              disabled={disabled || (!input.trim() && !mediaInput)}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 shadow-sm"
            >
              {disabled ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}
              <span>Ask</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}