import React from 'react';
import { ChefHat, Code, BookOpen, Shield, Cpu, Globe } from 'lucide-react';
import type { Domain } from '../types';

interface DomainSelectorProps {
  selectedDomain: Domain;
  onSelect: (domain: Domain) => void;
}

const DOMAINS = [
  { id: 'general' as Domain, name: 'General', icon: Globe, color: 'blue' },
  { id: 'cooking' as Domain, name: 'Cooking', icon: ChefHat, color: 'orange' },
  { id: 'development' as Domain, name: 'Development', icon: Code, color: 'purple' },
  { id: 'education' as Domain, name: 'Education', icon: BookOpen, color: 'green' },
  { id: 'cybersecurity' as Domain, name: 'Cybersecurity', icon: Shield, color: 'red' },
  { id: 'technology' as Domain, name: 'Technology', icon: Cpu, color: 'indigo' }
];

export function DomainSelector({ selectedDomain, onSelect }: DomainSelectorProps) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-2">
      {DOMAINS.map(({ id, name, icon: Icon, color }) => (
        <button
          key={id}
          onClick={() => onSelect(id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors
            ${selectedDomain === id 
              ? `bg-blue-100 text-blue-700 border-2 border-blue-200` 
              : `bg-white hover:bg-blue-50 text-gray-700 border border-gray-200`}`}
        >
          <Icon size={16} />
          <span>{name}</span>
        </button>
      ))}
    </div>
  );
}